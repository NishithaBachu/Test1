using NUnit.Framework;
using VillaPlus.PricingAPI.Managers;

namespace VillaPlusAPITest
{
    public class CalculateTotalPriceTest
    {
        private PriceCalculator _priceCalculator;

        [SetUp]
        public void Setup()
        {
            _priceCalculator = new PriceCalculator();
        }

        [Test]
        public void CalculateNoBonusPrice()
        {
            var result = _priceCalculator.CalculateNoBonusPrice(2, 100);
            Assert.AreEqual(result, 200, "Total price has calculated Without Applying any discount");
        }

        [Test]
        public void CalculateBuyTwoGetOnePrice()
        {
            var result = _priceCalculator.CalculateBuyTwoGetOnePrice(3, 50);
            Assert.AreEqual(result, 100, "Total price has caculated for only 2 items, as there is Buy 2 get 1 type applied");
        }
    }
}
