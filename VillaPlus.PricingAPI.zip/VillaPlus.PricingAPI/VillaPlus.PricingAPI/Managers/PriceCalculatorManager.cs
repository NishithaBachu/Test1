﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VillaPlus.PricingAPI.Interfaces;
using VillaPlus.PricingAPI.Models;

namespace VillaPlus.PricingAPI.Managers
{
    public class PriceCalculatorManager : IPriceCalculatorManager
    {
        private readonly IPriceCalculator _priceCalculator;

        public PriceCalculatorManager(IPriceCalculator priceCalculator)
        {
            _priceCalculator = priceCalculator;
        }

        public decimal CalculateTotalPrice(List<BasketItem> items)
        {
            try
            {
                decimal totalPrice = 0;

                //item id is unique for each unique product , if we add same item multiple times. ItemId remains same
                var uniqueItemIds = items.Select(x => x.ItemId).Distinct();

                foreach (var id in uniqueItemIds)
                {
                    var numberOfProductsForId = items.Count(x => x.ItemId == id);
                    var itemDetails = items.Where(x => x.ItemId == id).Select(x => x).FirstOrDefault();

                    if (itemDetails.Type == BonusType.NoBonus)
                        totalPrice = totalPrice + _priceCalculator.CalculateNoBonusPrice(numberOfProductsForId, itemDetails.ItemPrice);

                    if (itemDetails.Type == BonusType.BuyTwoGetOne)
                        totalPrice = totalPrice + _priceCalculator.CalculateBuyTwoGetOnePrice(numberOfProductsForId, itemDetails.ItemPrice);

                    //can be extended here if any new bonus type gets added
                }

                return totalPrice;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
