﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VillaPlus.PricingAPI.Interfaces;
using VillaPlus.PricingAPI.Models;

namespace VillaPlus.PricingAPI.Managers
{
    public class PriceCalculator: IPriceCalculator
    {
        public decimal CalculateNoBonusPrice(int itemsCount,decimal itemPrice)
        {
            return itemsCount * itemPrice;
        }

        public decimal CalculateBuyTwoGetOnePrice(int itemsCount, decimal itemPrice)
        {
            decimal totalPrice = 0;
            decimal numberOfDiscountItems = itemsCount / 3;

            if (itemsCount <= 2)
                return itemsCount * itemPrice;

            else {
                if ((itemsCount % 3) == 0)
                    return (itemsCount * itemPrice) - (numberOfDiscountItems * itemPrice);
                else
                    return (numberOfDiscountItems * 2 * itemPrice) + (itemsCount % 3) * itemPrice;
            }
        }

        //can be extended for new bonus types
    }
}
