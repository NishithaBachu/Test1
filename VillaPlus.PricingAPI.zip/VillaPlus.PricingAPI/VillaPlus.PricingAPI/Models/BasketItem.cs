﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VillaPlus.PricingAPI.Models
{
    public class BasketItem
    {
        public int ItemId { get; set; }
        public string ItemName { get; set; }

        public decimal ItemPrice { get; set; }
        public BonusType Type { get; set; }
    }
}
