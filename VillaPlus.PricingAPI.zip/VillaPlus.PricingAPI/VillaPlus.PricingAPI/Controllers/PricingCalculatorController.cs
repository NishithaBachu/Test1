﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VillaPlus.PricingAPI.Interfaces;
using VillaPlus.PricingAPI.Models;


namespace VillaPlus.PricingAPI.Controllers
{
    [EnableCors("MyPolicy")]
    [Route("api/[controller]")]
    [ApiController]

    public class PricingCalculatorController: ControllerBase
    {

        private readonly IPriceCalculatorManager _priceCalculatorManager;

        public PricingCalculatorController(IPriceCalculatorManager priceCalculatorManager)
        {
            _priceCalculatorManager = priceCalculatorManager;
        }

        [HttpPost]
        [Route("CalculateTotalPrice")]
        public decimal CalculateTotalPrice([FromBody] List<BasketItem> items)
        {
            if (items.Count() > 0)
                return _priceCalculatorManager.CalculateTotalPrice(items);
            else
                return 0;
        }

    }
}
