﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VillaPlus.PricingAPI.Models;

namespace VillaPlus.PricingAPI.Interfaces
{
    public interface IPriceCalculatorManager
    {
        decimal CalculateTotalPrice(List<BasketItem> items);
    }
}
