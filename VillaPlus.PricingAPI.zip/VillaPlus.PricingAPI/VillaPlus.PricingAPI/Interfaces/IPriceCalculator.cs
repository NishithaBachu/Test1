﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VillaPlus.PricingAPI.Models;

namespace VillaPlus.PricingAPI.Interfaces
{
    public interface IPriceCalculator
    {
        decimal CalculateNoBonusPrice(int numberOfItems,decimal itemPrice);

        decimal CalculateBuyTwoGetOnePrice(int numberOfItems, decimal itemPrice);

        //this interface is open to add any new bonustypes
    }
}
